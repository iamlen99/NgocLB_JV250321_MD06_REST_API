package ra.edu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TplusJv250321Md06Session04Application {

    public static void main(String[] args) {
        SpringApplication.run(TplusJv250321Md06Session04Application.class, args);
    }
}
