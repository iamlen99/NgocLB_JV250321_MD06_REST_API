package ra.edu.model.entity;

public enum RoleName {
    ADMIN,
    USER,
    EDITOR
}
