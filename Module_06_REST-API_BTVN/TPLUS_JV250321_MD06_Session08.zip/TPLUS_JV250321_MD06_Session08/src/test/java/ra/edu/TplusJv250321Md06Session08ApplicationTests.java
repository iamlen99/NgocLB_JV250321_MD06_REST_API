package ra.edu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TplusJv250321Md06Session08ApplicationTests {

    @Test
    void contextLoads() {
    }

}
